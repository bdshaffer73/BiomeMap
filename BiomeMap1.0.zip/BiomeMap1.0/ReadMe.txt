USAGE:

To use this plugin, you must have an available Spigot server. Visit https://www.spigotmc.org/wiki/spigot/for help setting one up.

The included BiomeMap.jar and BiomeMap folder must be placed in the server's plugins folder. It will not work any other way.

With the .jar and folder in the plugins folder, run the server. When the server is finished starting up (it has given the Done! signal), type "map-biomes". This will show you the names of all available worlds. Type "map-biomes" and a world name to generate a map of that world. Maps will be placed in the BiomeMap folder and will be named <world-name>.png.

Alternatively, set yourself as an op and enter the world. Type "/map-biomes" into the in-game command line and a map of the biomes of the world you are currently in will be generated in the same folder as before.

PERMISSIONS:

Anyone is allowed to use this plugin personally or in a modpack, but I must be notified via email if you want to edit the plugin. Mostly because I'm curious, but I also want credit where it's due. Cool? Cool.
